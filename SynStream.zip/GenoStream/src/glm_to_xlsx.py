#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PLINK2 --glm 결과(.glm.logistic.hybrid 등)를 보기 좋은 엑셀(.xlsx)로 변환.
- P값 오름차순 정렬, -log10(P) 추가
- genome-wide 유의(P<5e-8) 초록, suggestive(P<1e-5) 노랑 강조
- (선택) .causal.tsv 와 rsID 매칭해 '진짜 인과 SNP' 표시
- 요약 시트(유의 개수, 상위 SNP) 추가

사용:
  python glm_to_xlsx.py dm_chr11.DM.glm.logistic.hybrid
  python glm_to_xlsx.py dm_chr11.DM.glm.logistic.hybrid \
      --causal kchip_out/synthetic_kchip.causal.tsv --out dm_chr11.xlsx
"""

import argparse
import os
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

GW_SIG = 5e-8
SUGGESTIVE = 1e-5


def parse_args():
    p = argparse.ArgumentParser(description="PLINK2 glm 결과 -> xlsx")
    p.add_argument("infile", help=".glm.logistic.hybrid (또는 .linear) 파일")
    p.add_argument("--causal", default=None, help="정답 .causal.tsv (선택)")
    p.add_argument("--out", default=None, help="출력 xlsx 경로")
    return p.parse_args()


def load_glm(path):
    # PLINK2 헤더는 '#CHROM' 으로 시작하는 탭 구분 파일
    df = pd.read_csv(path, sep="\t")
    df.columns = [c.lstrip("#") for c in df.columns]
    # 숫자형 변환(존재하는 열만)
    for col in ("P", "OR", "LOG(OR)_SE", "Z_STAT", "T_STAT", "BETA",
                "A1_FREQ", "OBS_CT", "POS"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    # ADD(유전형 주효과)만 남기기 — hide-covar 안 썼을 때 대비
    if "TEST" in df.columns:
        df = df[df["TEST"] == "ADD"].copy()
    if "P" not in df.columns:
        raise SystemExit("P 열을 찾을 수 없습니다. 입력 파일을 확인하세요.")
    df = df.dropna(subset=["P"])
    df["NEG_LOG10_P"] = -np.log10(df["P"].clip(lower=1e-300))
    df["SIG"] = np.where(df["P"] < GW_SIG, "genome-wide",
                np.where(df["P"] < SUGGESTIVE, "suggestive", ""))
    df = df.sort_values("P").reset_index(drop=True)
    return df


def add_causal(df, causal_path):
    cz = pd.read_csv(causal_path, sep="\t")
    # rsID -> primary_pheno 매핑
    key = "rsID" if "rsID" in cz.columns else cz.columns[0]
    m = dict(zip(cz[key], cz.get("primary_pheno", cz.iloc[:, 3])))
    idcol = "ID" if "ID" in df.columns else df.columns[2]
    df["CAUSAL"] = df[idcol].map(m).fillna("")
    return df


def write_xlsx(df, out):
    wb = Workbook()
    ws = wb.active
    ws.title = "GWAS_results"

    hdr_font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
    hdr_fill = PatternFill("solid", fgColor="305496")
    base_font = Font(name="Arial", size=10)
    thin = Side(style="thin", color="D9D9D9")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    green = PatternFill("solid", fgColor="C6EFCE")   # genome-wide
    yellow = PatternFill("solid", fgColor="FFEB9C")  # suggestive
    causal_fill = PatternFill("solid", fgColor="D9E1F2")

    cols = list(df.columns)
    # 헤더
    for j, c in enumerate(cols, 1):
        cell = ws.cell(1, j, c)
        cell.font = hdr_font; cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border
    # 본문
    p_idx = cols.index("P") + 1
    or_idx = cols.index("OR") + 1 if "OR" in cols else None
    nlp_idx = cols.index("NEG_LOG10_P") + 1
    causal_idx = cols.index("CAUSAL") + 1 if "CAUSAL" in cols else None

    for i, (_, row) in enumerate(df.iterrows(), start=2):
        pval = row["P"]
        rowfill = green if pval < GW_SIG else (yellow if pval < SUGGESTIVE else None)
        for j, c in enumerate(cols, 1):
            cell = ws.cell(i, j, row[c])
            cell.font = base_font; cell.border = border
            if rowfill:
                cell.fill = rowfill
        ws.cell(i, p_idx).number_format = "0.00E+00"
        if or_idx:
            ws.cell(i, or_idx).number_format = "0.000"
        ws.cell(i, nlp_idx).number_format = "0.00"
        # 진짜 인과 SNP은 CAUSAL 칸을 파랑으로
        if causal_idx and str(row.get("CAUSAL", "")):
            ws.cell(i, causal_idx).fill = causal_fill
            ws.cell(i, causal_idx).font = Font(name="Arial", size=10, bold=True)

    # 틀 고정 + 필터 + 열너비
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{len(df)+1}"
    for j, c in enumerate(cols, 1):
        width = max(len(str(c)), *(len(str(v)) for v in df[c].head(200))) + 2
        ws.column_dimensions[get_column_letter(j)].width = min(max(width, 8), 24)

    # 요약 시트
    s = wb.create_sheet("Summary")
    n_gw = int((df["P"] < GW_SIG).sum())
    n_sug = int(((df["P"] >= GW_SIG) & (df["P"] < SUGGESTIVE)).sum())
    summary = [
        ["총 SNP 수", len(df)],
        ["genome-wide 유의 (P<5e-8)", n_gw],
        ["suggestive (5e-8≤P<1e-5)", n_sug],
        ["최소 P", f"{df['P'].min():.3e}"],
    ]
    if "CAUSAL" in df.columns:
        tp = int(((df["P"] < GW_SIG) & (df["CAUSAL"] != "")).sum())
        n_causal = int((df["CAUSAL"] != "").sum())
        summary += [["정답 인과 SNP 수(이 파일 내)", n_causal],
                    ["그 중 genome-wide 검출", tp]]
    for i, (k, v) in enumerate(summary, 1):
        s.cell(i, 1, k).font = Font(name="Arial", bold=True, size=10)
        s.cell(i, 2, v).font = Font(name="Arial", size=10)
    s.column_dimensions["A"].width = 30
    s.column_dimensions["B"].width = 16

    # 상위 15개 SNP 요약
    s.cell(1, 4, "상위 15개 SNP").font = Font(name="Arial", bold=True, size=10)
    top = df.head(15)
    idcol = "ID" if "ID" in df.columns else df.columns[2]
    heads = [idcol, "P", "OR", "CAUSAL"] if "OR" in df.columns else [idcol, "P", "CAUSAL"]
    heads = [h for h in heads if h in df.columns]
    for jj, h in enumerate(heads):
        s.cell(2, 4 + jj, h).font = Font(name="Arial", bold=True, size=10)
    for ii, (_, r) in enumerate(top.iterrows(), start=3):
        for jj, h in enumerate(heads):
            cell = s.cell(ii, 4 + jj, r[h])
            cell.font = Font(name="Arial", size=10)
            if h == "P":
                cell.number_format = "0.00E+00"
            if h == "OR":
                cell.number_format = "0.000"
    for jj in range(len(heads)):
        s.column_dimensions[get_column_letter(4 + jj)].width = 14

    wb.save(out)


def main():
    a = parse_args()
    df = load_glm(a.infile)
    if a.causal and os.path.exists(a.causal):
        df = add_causal(df, a.causal)
    out = a.out or (os.path.splitext(a.infile)[0] + ".xlsx")
    write_xlsx(df, out)
    n_gw = int((df["P"] < GW_SIG).sum())
    print(f"[done] {out}  (총 {len(df):,} SNP, genome-wide 유의 {n_gw}개)")


if __name__ == "__main__":
    main()
