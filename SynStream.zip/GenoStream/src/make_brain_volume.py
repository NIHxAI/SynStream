#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
뇌영상 체적(ROI) 가상 데이터 생성기 — NeuroStream 형식
========================================================
입력
  - 코호트 txt: T_ID, T_SEX(1남/2여), T_AGE, T_HTN/T_DM/T_LIP(1정상/2질환/99999결측)
  - NeuroStream 샘플 CSV(assets/cohort*_sample_updated.csv): ROI 열·평균·SD 앵커
  - (내장) 만성질환/뇌영상 유전변이 효과: APOE ε4, ENIGMA 좌위(TESC/MSRB3/KTN1/HMGA2)

설계
  - 66개 뇌 ROI 체적을 개체별로 생성. 실제 샘플의 평균±SD를 앵커로 사용.
  - 공변량 효과:
      * ICV(머리 크기): 성별 + HMGA2 유전효과, 각 부위는 ICV에 부분 비례
      * 나이: 조직 위축(해마·내후각피질 강함), 뇌실 확장
      * 질환(고혈압/당뇨/고지혈증): 조직 위축·뇌실 확장 (당뇨>고혈압>고지혈증)
      * 유전: APOE ε4 → 해마·내후각·편도 위축, 뇌실 확장 / TESC·MSRB3 → 해마 / KTN1 → 조가비핵
  - 좌우(L/R) 및 상위-하위 체적 관계를 근사적으로 일관되게 구성
      (whole_brain=GM+WM+소뇌, lateral_ventricle_w_inf=lateral+inf, L+R=total)

주의: NeuroStream 코딩은 htn/dm {1:질환, 2:비질환} 으로 우리 코호트(1정상/2질환)와 반대.
      → cov_htn/cov_dm 는 질환=1, 정상=2 로 변환. 성별(1남2여)은 동일.
효과크기·MAF는 문헌 기반 예시값(정확값 아님), 인자로 조정 가능.
"""

import argparse
import os
import numpy as np
import pandas as pd

# ---- 뇌영상 유전변이(예시): rsID -> (유전자, EAS MAF) ----
BRAIN_SNPS = {
    "rs7294919":  ("TESC",  0.35),   # 해마 체적 (ENIGMA)
    "rs77956314": ("MSRB3", 0.20),   # 해마 체적 (ENIGMA)
    "rs945270":   ("KTN1",  0.45),   # 조가비핵(putamen) 체적 (ENIGMA)
    "rs10784502": ("HMGA2", 0.45),   # 두개내용적(ICV)
}
APOE_E4_FREQ = 0.09                   # 한국인 APOE ε4 대립유전자 빈도(근사)

# ---- L/R 로 분할할 (total, lh, rh) 열 그룹 ----
LR_GROUPS = [
    ("ctx_cerebral_grey_matter_307", "ctx_lh_cerebral_grey_matter_407", "ctx_rh_cerebral_grey_matter_507"),
    ("cerebral_white_matter_1",      "lh_cerebral_white_matter_101",    "rh_cerebral_white_matter_201"),
    ("ctx_frontal_lobe_301",         "ctx_lh_frontal_lobe_401",         "ctx_rh_frontal_lobe_501"),
    ("ctx_temporal_lobe_302",        "ctx_lh_temporal_lobe_402",        "ctx_rh_temporal_lobe_502"),
    ("ctx_parietal_lobe_303",        "ctx_lh_parietal_lobe_403",        "ctx_rh_parietal_lobe_503"),
    ("ctx_occipital_lobe_304",       "ctx_lh_occipital_lobe_404",       "ctx_rh_occipital_lobe_504"),
    ("ctx_cingulate_305",            "ctx_lh_cingulate_405",            "ctx_rh_cingulate_505"),
    ("lateral_ventricle_w_inf_308",  "lh_lateral_ventricle_w_inf_408",  "rh_lateral_ventricle_w_inf_508"),
    ("whole_brain_323",              "lh_whole_brain_423",              "rh_whole_brain_523"),
    ("cerebellum_306",               "lh_cerebellum_406",               "rh_cerebellum_506"),
]

# 내측두엽 등 위축 민감 부위(강한 나이/질환 효과)
SENSITIVE = {
    "subctx_hippocampus_10", "subctx_amygdala_11", "ctx_entorhinal_18",
    "ctx_parahippocampal_28", "ctx_fusiform_19", "ctx_inferior_temporal_21",
    "ctx_middle_temporal_27", "ctx_superior_temporal_42", "ctx_temporal_lobe_302",
}


def parse_args():
    p = argparse.ArgumentParser(description="뇌영상 체적 가상데이터 생성기(NeuroStream 형식)")
    p.add_argument("--cohort", default="BASE_Cohort_base.txt")
    p.add_argument("--sample-dir", default="NeuroStream/assets",
                   help="NeuroStream cohort*_sample_updated.csv 폴더")
    p.add_argument("--outdir", default="brain_out")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def load_cohort(path):
    df = pd.read_csv(path, sep="\t")
    return df


def load_sample_stats(sample_dir):
    frames = []
    for f in os.listdir(sample_dir):
        if f.endswith(".csv") and "sample" in f:
            frames.append(pd.read_csv(os.path.join(sample_dir, f)))
    if not frames:
        raise SystemExit("NeuroStream 샘플 CSV를 찾을 수 없습니다.")
    df = pd.concat(frames, ignore_index=True)
    cols = list(df.columns)
    cov = {"cohort", "age_group", "cov_gender", "cov_edu_level",
           "cov_htn", "cov_dm", "cov_age"}
    roi = [c for c in cols if c not in cov]
    stats = {c: (float(df[c].mean()), float(df[c].std())) for c in roi}
    return cols, roi, stats


def age_group(age):
    return np.clip(age // 10 - 4, 0, 4).astype(int)


def region_params(r):
    """부위별 (나이 위축율, 고혈압, 당뇨, 고지혈증 효과, 종류)."""
    is_vent = ("ventricle" in r) or (r == "inf_lat_vent_3")
    if is_vent:
        return dict(age=+0.020, htn=+0.08, dm=+0.12, lip=+0.03, kind="vent")
    if r in SENSITIVE:
        return dict(age=0.007, htn=0.015, dm=0.025, lip=0.008, kind="tissue")
    if r in ("ctx_cerebral_grey_matter_307",):
        return dict(age=0.004, htn=0.010, dm=0.015, lip=0.005, kind="tissue")
    if r in ("cerebral_white_matter_1",):
        return dict(age=0.002, htn=0.012, dm=0.012, lip=0.004, kind="tissue")
    if r in ("cerebellum_306",):
        return dict(age=0.0015, htn=0.003, dm=0.004, lip=0.002, kind="tissue")
    return dict(age=0.003, htn=0.008, dm=0.012, lip=0.004, kind="tissue")


def main():
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    os.makedirs(args.outdir, exist_ok=True)

    coh = load_cohort(args.cohort)
    cols, roi, stats = load_sample_stats(args.sample_dir)
    N = len(coh)
    print(f"[info] 개체 {N:,} | ROI {len(roi)}개 (NeuroStream 형식)")

    age = coh["T_AGE"].to_numpy()
    sex = coh["T_SEX"].to_numpy()                 # 1남 2여 (NeuroStream 동일)
    # 질환: 코호트 1정상/2질환/99999결측 -> NeuroStream 1질환/2정상, 결측 99999
    def to_ns(v):
        out = np.full(N, 99999)
        out[v == 2] = 1     # 질환
        out[v == 1] = 2     # 정상
        return out
    htn_ns = to_ns(coh["T_HTN"].to_numpy())
    dm_ns = to_ns(coh["T_DM"].to_numpy())
    lip_ns = to_ns(coh["T_LIP"].to_numpy())
    # 효과용 0/1 지시자(질환=1)
    htn = (htn_ns == 1).astype(float)
    dm = (dm_ns == 1).astype(float)
    lip = (lip_ns == 1).astype(float)

    # ---- 유전형 생성 ----
    apoe_e4 = rng.binomial(2, APOE_E4_FREQ, size=N)          # ε4 대립유전자 수 0/1/2
    snp_geno = {rs: rng.binomial(2, maf, size=N)
                for rs, (g, maf) in BRAIN_SNPS.items()}

    # ---- ICV(두개내용적): 성별 + HMGA2 ----
    mean_icv = np.where(sex == 1, 1500.0, 1450.0)
    icv = rng.normal(mean_icv, 130.0)
    icv *= (1 + 0.015 * snp_geno["rs10784502"])              # HMGA2 per allele +1.5%
    icv = np.clip(icv, 1000, 2100)
    size = icv / 1473.0                                       # 크기 인자(샘플 평균 기준)
    age_dev = age - 60.0

    # 부위별 유전 수식자
    g_hippo = 1 - 0.03 * apoe_e4 - 0.020 * snp_geno["rs7294919"] - 0.015 * snp_geno["rs77956314"]
    g_ento = 1 - 0.04 * apoe_e4
    g_amyg = 1 - 0.02 * apoe_e4
    g_parahip = 1 - 0.02 * apoe_e4
    g_putamen = 1 + 0.018 * snp_geno["rs945270"]
    g_vent = 1 + 0.04 * apoe_e4

    def gen_factor_multiplier(r):
        if r == "subctx_hippocampus_10": return g_hippo
        if r == "ctx_entorhinal_18": return g_ento
        if r == "subctx_amygdala_11": return g_amyg
        if r == "ctx_parahippocampal_28": return g_parahip
        if r == "subctx_putamen_8": return g_putamen
        return None

    # ---- ROI 생성 ----
    data = {}
    for r in roi:
        if r == "icv_300":
            data[r] = icv.copy()
            continue
        if r in ("whole_brain_323", "lateral_ventricle_w_inf_308", "ventricles_309"):
            continue  # 파생: 아래에서 계산
        mean_r, sd_r = stats[r]
        pr = region_params(r)
        if pr["kind"] == "vent":
            f = (1 + pr["age"] * age_dev + pr["htn"] * htn + pr["dm"] * dm
                 + pr["lip"] * lip) * g_vent
            f = np.clip(f, 0.2, None)
            val = mean_r * f * (0.5 + 0.5 * size)
        else:
            f = (1 - pr["age"] * age_dev - pr["htn"] * htn - pr["dm"] * dm
                 - pr["lip"] * lip)
            gm = gen_factor_multiplier(r)
            if gm is not None:
                f = f * gm
            f = np.clip(f, 0.3, None)
            val = mean_r * f * (1 + 0.7 * (size - 1))
        val += rng.normal(0, 0.62 * sd_r, size=N)
        data[r] = np.clip(val, 0.05 * mean_r, None)

    # ---- 파생/일관성 ----
    # 측뇌실(하각 포함) = 측뇌실 + 하각
    data["lateral_ventricle_w_inf_308"] = data["lateral_ventricle_2"] + data["inf_lat_vent_3"]
    # 전체 뇌실 = 측뇌실(하각포함) + 3·4뇌실(소량)
    data["ventricles_309"] = data["lateral_ventricle_w_inf_308"] + rng.normal(6, 2, N).clip(1)
    # whole brain = 대뇌 GM + 대뇌 WM + 소뇌
    data["whole_brain_323"] = (data["ctx_cerebral_grey_matter_307"]
                               + data["cerebral_white_matter_1"] + data["cerebellum_306"])

    # ---- L/R 분할 (L+R=total) ----
    for total, lh, rh in LR_GROUPS:
        p = np.clip(rng.normal(0.5, 0.02, N), 0.4, 0.6)
        data[lh] = data[total] * p
        data[rh] = data[total] * (1 - p)

    # ---- 공변량 ----
    edu = rng.choice([0, 1, 2, 3, 4, 5, 6, 99999], size=N,
                     p=[0.03, 0.15, 0.20, 0.32, 0.10, 0.13, 0.05, 0.02])
    out = pd.DataFrame({
        "cohort": "SynthKChip",
        "age_group": age_group(age),
        "cov_gender": sex,
        "cov_edu_level": edu,
        "cov_htn": htn_ns,
        "cov_dm": dm_ns,
    })
    for r in roi:
        out[r] = np.round(data[r], 3)
    out["cov_age"] = age
    # NeuroStream 표준 73열 순서로 정렬
    out = out[cols]
    ns_path = os.path.join(args.outdir, "brain_volume_synthetic_neurostream.csv")
    out.to_csv(ns_path, index=False)

    # ---- 확장본(ID·고지혈증·APOE·뇌영상 SNP 포함, 영상유전 분석용) ----
    ext = out.copy()
    ext.insert(0, "IID", coh["T_ID"].to_numpy())
    ext.insert(7, "cov_lip", lip_ns)
    ext.insert(8, "cov_apoe_e4", apoe_e4)       # ε4 대립유전자 수(0/1/2)
    for rs in BRAIN_SNPS:
        ext[rs] = snp_geno[rs]
    ext_path = os.path.join(args.outdir, "brain_volume_synthetic_extended.csv")
    ext.to_csv(ext_path, index=False)

    # ---- 정답(효과) 주석 ----
    truth = os.path.join(args.outdir, "brain_effects_truth.tsv")
    with open(truth, "w") as f:
        f.write("factor\ttarget_ROI\teffect\tnote\n")
        f.write("age\t조직 전반\t위축(민감부위 강함)\t해마·내후각 ~0.7%/yr, 뇌실 +2.5%/yr\n")
        f.write("HTN(고혈압)\t해마·조직·뇌실\t위축/확장\t해마 -1.5%, 뇌실 +8%\n")
        f.write("DM(당뇨)\t해마·조직·뇌실\t위축/확장\t해마 -2.5%, 뇌실 +12%\n")
        f.write("LIP(고지혈증)\t조직\t경미 위축\t해마 -0.8%\n")
        f.write("APOE_e4\t해마·내후각·편도·뇌실\t위축/확장\t해마 -3%/allele, 뇌실 +4%/allele\n")
        for rs, (g, maf) in BRAIN_SNPS.items():
            tgt = {"rs7294919": "해마", "rs77956314": "해마",
                   "rs945270": "조가비핵", "rs10784502": "ICV"}[rs]
            f.write(f"{rs}({g})\t{tgt}\tper-allele\tMAF≈{maf}\n")

    # ---- 요약/검증 ----
    print(f"[done] NeuroStream 형식: {ns_path}")
    print(f"[done] 확장본(영상유전): {ext_path}")
    print(f"[done] 효과 주석: {truth}")
    hip = out["subctx_hippocampus_10"].to_numpy()
    print("\n[검증] 해마 체적(평균):")
    print(f"  전체 {hip.mean():.2f} (샘플앵커 {stats['subctx_hippocampus_10'][0]:.2f})")
    print(f"  고혈압 {hip[htn==1].mean():.2f} vs 정상 {hip[htn==0].mean():.2f}")
    print(f"  당뇨   {hip[dm==1].mean():.2f} vs 정상 {hip[dm==0].mean():.2f}")
    print(f"  APOE ε4보유 {hip[apoe_e4>0].mean():.2f} vs 비보유 {hip[apoe_e4==0].mean():.2f}")
    lv = out["lateral_ventricle_2"].to_numpy()
    print(f"[검증] 측뇌실: 고혈압 {lv[htn==1].mean():.2f} vs 정상 {lv[htn==0].mean():.2f} (질환↑ 기대)")


if __name__ == "__main__":
    main()
