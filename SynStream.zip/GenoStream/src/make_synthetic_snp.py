#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
코호트 + 한국인 질환 SNP 카탈로그 기반 합성 SNP chip 생성기 (v3)
===============================================================
v2 대비 변경점
  (1) 염색체별 분할 출력: chr1..chr22 각각 별도 .bed/.bim (+ 공유 .fam)
      → 단일 거대 파일 대신 염색체 단위로 나눠 저장/열람
  (2) GWAS 유의성 보장: 인과(위험) SNP가 후속 연관분석에서 genome-wide
      유의(p<5e-8)하게 검출되도록 효과크기(OR)·MAF를 튜닝하고,
      생성 직후 Cochran-Armitage 추세검정으로 p값을 자체 검증/리포트
  (3) 한국인/동아시아 특이 변이 추가: ALDH2·PAX4·CDKAL1·ATP2B1·APOA5 등
      EAS enriched(유럽인에서는 희귀) 위험 변이를 큐레이션 세트로 주입

입력
  - 코호트 txt: T_ID,T_SEX(1남/2여),T_AGE,T_HTN,T_DM,T_LIP (1정상/2질환/99999결측)
  - SNP 카탈로그 xlsx: '3. SNP 카탈로그' 시트

주의: MAF/OR/염색체 좌표는 EAS 근사·예시값(문헌상 좌위에 기반)이며 인자로 조정 가능.
      정확값이 필요하면 gnomAD EAS/한국인 레퍼런스로 대체.
"""

import argparse
import math
import os
import shutil
import time
import numpy as np

try:
    import openpyxl
except ImportError:
    raise SystemExit("openpyxl 필요: python -m pip install openpyxl")

# ---------- PLINK .bed 인코딩 (A1=minor=위험대립유전자) ----------
GENO_TO_CODE = np.array([3, 2, 0, 1], dtype=np.uint8)  # dosage 0/1/2/결측3 -> code
NUCLEOTIDES = np.array(list("ACGT"))
BED_MAGIC = b"\x6c\x1b\x01"
GW_SIG = 5e-8  # genome-wide 유의수준

# ---------- 표현형 분류 키워드 ----------
PHENO_KEYWORDS = {
    "HTN": ["hypertension", "blood pressure", "cardiovascular", "coronary"],
    "DM":  ["diabetes", "glucose"],
    "LIP": ["lipid", "cholesterol", "triglyceride", "ldl", "hdl"],
}
PHENO_PRIORITY = ["DM", "LIP", "HTN"]

# ---------- GRCh38 상염색체 길이(bp) ----------
CHR_LEN = {
    1: 248956422, 2: 242193529, 3: 198295559, 4: 190214555, 5: 181538259,
    6: 170805979, 7: 159345973, 8: 145138636, 9: 138394717, 10: 133797422,
    11: 135086622, 12: 133275309, 13: 114364328, 14: 107043718, 15: 101991189,
    16: 90338345, 17: 83257441, 18: 80373285, 19: 58617616, 20: 64444167,
    21: 46709983, 22: 50818468,
}

# ---------- 유전자 -> 염색체 (카탈로그 유전자 매핑; 없으면 분산배치) ----------
GENE_CHR = {
    "ALDH2": 12, "APOE": 19, "APOA5": 11, "CETP": 16, "FGF5": 4, "GCKR": 2,
    "KCNQ1": 11, "PNPLA3": 22, "MYL2": 12, "CDKN2B-AS1": 9, "HNF1A": 12,
    "ADH1B": 4, "GC": 4, "TAS2R38": 7, "TAS2R4": 7, "GDF6": 8, "SIX6": 14,
    "CAV1/CAV2": 7, "CLOCK": 4, "CYP2D6": 22, "ABO": 9, "PCAT1": 8,
    "NKX2-1/PTCSC2": 14, "BDNF": 11, "CDKN2B": 9,
    # --- 확장(GWAS Catalog 다인종 좌위) ---
    "TCF7L2": 10, "PPARG": 3, "KCNJ11": 11, "SLC30A8": 8, "HHEX": 10,
    "CDKAL1": 6, "IGF2BP2": 3, "FTO": 16, "MTNR1B": 11, "JAZF1": 7,
    "TSPAN8": 12, "THADA": 2, "ADAMTS9": 3, "NOTCH2": 1, "CDC123": 10,
    "WFS1": 4, "PAX4": 7, "ATP2B1": 12, "CYP17A1": 10, "MTHFR": 1,
    "CASZ1": 1, "SH2B3": 12, "CSK": 15, "ZNF652": 17, "PLEKHA7": 11,
    "CACNB2": 10, "ULK4": 3, "C10orf107": 10, "PLCD3": 17, "NPPB": 1,
    "HECTD4": 12, "CYP11B2": 8, "PCSK9": 1, "APOB": 2, "LDLR": 19,
    "LPL": 8, "LIPC": 15, "SORT1": 1, "HMGCR": 5, "ABCG8": 2,
    "TRIB1": 8, "MLXIPL": 7, "ANGPTL3": 1, "APOA1": 11,
}

# ---------- 유명 변이 EAS 근사 MAF (예시/조정용) ----------
APPROX_EAS_MAF = {
    "rs671": 0.25, "rs16998073": 0.30, "rs2237892": 0.35, "rs1260326": 0.45,
    "rs429358": 0.09, "rs7412": 0.09, "rs405509": 0.45, "rs449647": 0.10,
    "rs769446": 0.12, "rs662799": 0.30, "rs651821": 0.30, "rs2266788": 0.28,
    "rs708272": 0.42, "rs12229654": 0.20, "rs10757272": 0.45,
    "rs2157719": 0.45, "rs7865618": 0.45,
}

# ---------- (3) GWAS Catalog 기반 다인종 큐레이션 위험 변이 세트 ----------
# 한국인/동아시아 + 유럽·다인종에서 확립된 세 만성질환(고혈압/당뇨/고지혈증)
# 대표 좌위. anc=주 보고 인종(EAS/EUR/MULTI). maf/orr는 문헌 기반 예시값(정확값 아님).
# 참고: EBI GWAS Catalog(https://www.ebi.ac.uk/gwas/) 및 각 질환 컨소시엄 메타분석.
CURATED_GWAS = [
    # ================= 당뇨 (Type 2 diabetes) =================
    dict(rsid="rs7903146",  gene="TCF7L2",  chr=10, pheno="DM",  maf=0.30, orr=1.45, anc="MULTI", note="TCF7L2, 최강 T2D 좌위"),
    dict(rsid="rs1801282",  gene="PPARG",   chr=3,  pheno="DM",  maf=0.12, orr=1.20, anc="EUR"),
    dict(rsid="rs5219",     gene="KCNJ11",  chr=11, pheno="DM",  maf=0.37, orr=1.15, anc="MULTI"),
    dict(rsid="rs13266634", gene="SLC30A8", chr=8,  pheno="DM",  maf=0.45, orr=1.15, anc="MULTI"),
    dict(rsid="rs1111875",  gene="HHEX",    chr=10, pheno="DM",  maf=0.40, orr=1.15, anc="MULTI"),
    dict(rsid="rs10946398", gene="CDKAL1",  chr=6,  pheno="DM",  maf=0.31, orr=1.20, anc="MULTI"),
    dict(rsid="rs7754840",  gene="CDKAL1",  chr=6,  pheno="DM",  maf=0.45, orr=1.20, anc="EAS"),
    dict(rsid="rs10811661", gene="CDKN2A/B",chr=9,  pheno="DM",  maf=0.45, orr=1.20, anc="MULTI"),
    dict(rsid="rs4402960",  gene="IGF2BP2", chr=3,  pheno="DM",  maf=0.30, orr=1.17, anc="MULTI"),
    dict(rsid="rs8050136",  gene="FTO",     chr=16, pheno="DM",  maf=0.40, orr=1.17, anc="MULTI"),
    dict(rsid="rs2237892",  gene="KCNQ1",   chr=11, pheno="DM",  maf=0.35, orr=1.40, anc="EAS"),
    dict(rsid="rs163184",   gene="KCNQ1",   chr=11, pheno="DM",  maf=0.40, orr=1.30, anc="EAS"),
    dict(rsid="rs10830963", gene="MTNR1B",  chr=11, pheno="DM",  maf=0.30, orr=1.15, anc="MULTI"),
    dict(rsid="rs864754",   gene="JAZF1",   chr=7,  pheno="DM",  maf=0.50, orr=1.10, anc="EUR"),
    dict(rsid="rs7961581",  gene="TSPAN8",  chr=12, pheno="DM",  maf=0.27, orr=1.10, anc="EUR"),
    dict(rsid="rs7578597",  gene="THADA",   chr=2,  pheno="DM",  maf=0.10, orr=1.15, anc="EUR"),
    dict(rsid="rs4607103",  gene="ADAMTS9", chr=3,  pheno="DM",  maf=0.28, orr=1.12, anc="EUR"),
    dict(rsid="rs10923931", gene="NOTCH2",  chr=1,  pheno="DM",  maf=0.10, orr=1.13, anc="EUR"),
    dict(rsid="rs12779790", gene="CDC123",  chr=10, pheno="DM",  maf=0.20, orr=1.11, anc="EUR"),
    dict(rsid="rs10010131", gene="WFS1",    chr=4,  pheno="DM",  maf=0.40, orr=1.12, anc="EUR"),
    dict(rsid="rs2233580",  gene="PAX4",    chr=7,  pheno="DM",  maf=0.09, orr=1.70, anc="EAS", note="PAX4 R192H, EAS-특이"),
    # ================= 고혈압 (Blood pressure / hypertension) =================
    dict(rsid="rs16998073", gene="FGF5",    chr=4,  pheno="HTN", maf=0.30, orr=1.45, anc="MULTI"),
    dict(rsid="rs17249754", gene="ATP2B1",  chr=12, pheno="HTN", maf=0.35, orr=1.40, anc="MULTI"),
    dict(rsid="rs11191548", gene="CYP17A1", chr=10, pheno="HTN", maf=0.10, orr=1.30, anc="MULTI"),
    dict(rsid="rs17367504", gene="MTHFR",   chr=1,  pheno="HTN", maf=0.15, orr=1.25, anc="MULTI"),
    dict(rsid="rs880315",   gene="CASZ1",   chr=1,  pheno="HTN", maf=0.35, orr=1.40, anc="EAS"),
    dict(rsid="rs3184504",  gene="SH2B3",   chr=12, pheno="HTN", maf=0.47, orr=1.20, anc="EUR"),
    dict(rsid="rs1378942",  gene="CSK",     chr=15, pheno="HTN", maf=0.35, orr=1.15, anc="MULTI"),
    dict(rsid="rs16948048", gene="ZNF652",  chr=17, pheno="HTN", maf=0.38, orr=1.12, anc="EUR"),
    dict(rsid="rs381815",   gene="PLEKHA7", chr=11, pheno="HTN", maf=0.26, orr=1.13, anc="EUR"),
    dict(rsid="rs11014166", gene="CACNB2",  chr=10, pheno="HTN", maf=0.33, orr=1.12, anc="EUR"),
    dict(rsid="rs3774372",  gene="ULK4",    chr=3,  pheno="HTN", maf=0.17, orr=1.13, anc="EUR"),
    dict(rsid="rs1530440",  gene="C10orf107",chr=10,pheno="HTN", maf=0.22, orr=1.13, anc="EUR"),
    dict(rsid="rs12946454", gene="PLCD3",   chr=17, pheno="HTN", maf=0.28, orr=1.12, anc="EUR"),
    dict(rsid="rs5068",     gene="NPPB",    chr=1,  pheno="HTN", maf=0.11, orr=1.20, anc="EUR"),
    dict(rsid="rs11066280", gene="HECTD4",  chr=12, pheno="HTN", maf=0.25, orr=1.50, anc="EAS", note="12q24, EAS-특이"),
    dict(rsid="rs1799998",  gene="CYP11B2", chr=8,  pheno="HTN", maf=0.40, orr=1.15, anc="MULTI"),
    # ================= 고지혈증 (Lipids / dyslipidemia) =================
    dict(rsid="rs11206510", gene="PCSK9",   chr=1,  pheno="LIP", maf=0.16, orr=1.30, anc="EUR", note="PCSK9, LDL"),
    dict(rsid="rs693",      gene="APOB",    chr=2,  pheno="LIP", maf=0.45, orr=1.30, anc="MULTI", note="APOB, LDL/ApoB"),
    dict(rsid="rs6511720",  gene="LDLR",    chr=19, pheno="LIP", maf=0.11, orr=1.30, anc="EUR", note="LDLR, LDL"),
    dict(rsid="rs328",      gene="LPL",     chr=8,  pheno="LIP", maf=0.10, orr=1.30, anc="MULTI", note="LPL S447X, TG/HDL"),
    dict(rsid="rs662799",   gene="APOA5",   chr=11, pheno="LIP", maf=0.30, orr=1.50, anc="EAS", note="APOA5, TG"),
    dict(rsid="rs2075291",  gene="APOA5",   chr=11, pheno="LIP", maf=0.07, orr=1.90, anc="EAS", note="APOA5 G185C, EAS-특이 고TG"),
    dict(rsid="rs3764261",  gene="CETP",    chr=16, pheno="LIP", maf=0.32, orr=1.40, anc="MULTI", note="CETP, HDL"),
    dict(rsid="rs708272",   gene="CETP",    chr=16, pheno="LIP", maf=0.42, orr=1.50, anc="MULTI", note="CETP TaqIB, HDL"),
    dict(rsid="rs1800588",  gene="LIPC",    chr=15, pheno="LIP", maf=0.30, orr=1.20, anc="MULTI", note="LIPC, HDL"),
    dict(rsid="rs629301",   gene="SORT1",   chr=1,  pheno="LIP", maf=0.22, orr=1.30, anc="EUR", note="SORT1/CELSR2, LDL"),
    dict(rsid="rs12916",    gene="HMGCR",   chr=5,  pheno="LIP", maf=0.40, orr=1.20, anc="MULTI", note="HMGCR, LDL"),
    dict(rsid="rs4299376",  gene="ABCG8",   chr=2,  pheno="LIP", maf=0.30, orr=1.20, anc="EUR", note="ABCG5/8, LDL"),
    dict(rsid="rs2954029",  gene="TRIB1",   chr=8,  pheno="LIP", maf=0.47, orr=1.20, anc="MULTI", note="TRIB1, TG/LDL"),
    dict(rsid="rs17145738", gene="MLXIPL",  chr=7,  pheno="LIP", maf=0.12, orr=1.30, anc="EUR", note="MLXIPL, TG"),
    dict(rsid="rs2131925",  gene="ANGPTL3", chr=1,  pheno="LIP", maf=0.32, orr=1.20, anc="EUR", note="ANGPTL3, TG/LDL"),
]

# ---------- (4) 후보 유전자 세트 (약한 효과 → 목표 p > 1e-5) ----------
# 실제 질환 연관이 보고됐으나 효과가 약해 이 코호트 규모에서는 genome-wide에
# 못 미치는 '후보(candidate)' 좌위. 검정력 보정(boost)에서 제외되어 약한 OR 유지.
CANDIDATE_GENES = [
    # ---- 당뇨 후보 ----
    dict(rsid="rs340874",   gene="PROX1",   chr=1,  pheno="DM",  maf=0.35, orr=1.12, anc="EUR"),
    dict(rsid="rs2191349",  gene="DGKB",    chr=7,  pheno="DM",  maf=0.47, orr=1.11, anc="EUR"),
    dict(rsid="rs11708067", gene="ADCY5",   chr=3,  pheno="DM",  maf=0.22, orr=1.12, anc="EUR"),
    dict(rsid="rs7034200",  gene="GLIS3",   chr=9,  pheno="DM",  maf=0.42, orr=1.10, anc="MULTI"),
    dict(rsid="rs4430796",  gene="HNF1B",   chr=17, pheno="DM",  maf=0.45, orr=1.11, anc="EUR"),
    dict(rsid="rs972283",   gene="KLF14",   chr=7,  pheno="DM",  maf=0.45, orr=1.10, anc="EUR"),
    dict(rsid="rs10423928", gene="GIPR",    chr=19, pheno="DM",  maf=0.20, orr=1.11, anc="EUR"),
    dict(rsid="rs896854",   gene="TP53INP1",chr=8,  pheno="DM",  maf=0.48, orr=1.10, anc="MULTI"),
    dict(rsid="rs4457053",  gene="ZBED3",   chr=5,  pheno="DM",  maf=0.26, orr=1.11, anc="EUR"),
    dict(rsid="rs1531343",  gene="HMGA2",   chr=12, pheno="DM",  maf=0.10, orr=1.13, anc="EUR"),
    dict(rsid="rs1552224",  gene="ARAP1",   chr=11, pheno="DM",  maf=0.16, orr=1.13, anc="EUR"),
    dict(rsid="rs16861329", gene="ST6GAL1", chr=3,  pheno="DM",  maf=0.30, orr=1.10, anc="EAS"),
    dict(rsid="rs7957197",  gene="HNF1A",   chr=12, pheno="DM",  maf=0.15, orr=1.08, anc="EUR"),
    dict(rsid="rs7172432",  gene="C2CD4A",  chr=15, pheno="DM",  maf=0.40, orr=1.10, anc="EAS"),
    # ---- 고혈압 후보 (케이스 많아 OR 더 작게) ----
    dict(rsid="rs1801253",  gene="ADRB1",   chr=10, pheno="HTN", maf=0.27, orr=1.07, anc="MULTI"),
    dict(rsid="rs699",      gene="AGT",     chr=1,  pheno="HTN", maf=0.40, orr=1.07, anc="MULTI"),
    dict(rsid="rs1799983",  gene="NOS3",    chr=7,  pheno="HTN", maf=0.33, orr=1.06, anc="MULTI"),
    dict(rsid="rs4961",     gene="ADD1",    chr=4,  pheno="HTN", maf=0.20, orr=1.07, anc="MULTI"),
    dict(rsid="rs5443",     gene="GNB3",    chr=12, pheno="HTN", maf=0.30, orr=1.06, anc="MULTI"),
    dict(rsid="rs3754777",  gene="STK39",   chr=2,  pheno="HTN", maf=0.10, orr=1.08, anc="EUR"),
    dict(rsid="rs13139571", gene="GUCY1A3", chr=4,  pheno="HTN", maf=0.24, orr=1.07, anc="EUR"),
    dict(rsid="rs932764",   gene="PLCE1",   chr=10, pheno="HTN", maf=0.44, orr=1.06, anc="EUR"),
    dict(rsid="rs1173771",  gene="NPR3",    chr=5,  pheno="HTN", maf=0.40, orr=1.06, anc="EUR"),
    dict(rsid="rs2521501",  gene="FURIN",   chr=15, pheno="HTN", maf=0.30, orr=1.07, anc="EUR"),
    dict(rsid="rs2932538",  gene="MOV10",   chr=1,  pheno="HTN", maf=0.25, orr=1.06, anc="EUR"),
    dict(rsid="rs2384550",  gene="TBX3",    chr=12, pheno="HTN", maf=0.35, orr=1.06, anc="EUR"),
    # ---- 고지혈증 후보 ----
    dict(rsid="rs3890182",  gene="ABCA1",   chr=9,  pheno="LIP", maf=0.12, orr=1.13, anc="MULTI"),
    dict(rsid="rs255052",   gene="LCAT",    chr=16, pheno="LIP", maf=0.30, orr=1.11, anc="EUR"),
    dict(rsid="rs4846914",  gene="GALNT2",  chr=1,  pheno="LIP", maf=0.40, orr=1.10, anc="MULTI"),
    dict(rsid="rs2000813",  gene="LIPG",    chr=18, pheno="LIP", maf=0.30, orr=1.11, anc="EUR"),
    dict(rsid="rs174547",   gene="FADS1",   chr=11, pheno="LIP", maf=0.35, orr=1.11, anc="MULTI"),
    dict(rsid="rs2338104",  gene="MVK",     chr=12, pheno="LIP", maf=0.45, orr=1.10, anc="EUR"),
    dict(rsid="rs16996148", gene="NCAN",    chr=19, pheno="LIP", maf=0.08, orr=1.14, anc="EUR"),
    dict(rsid="rs6882076",  gene="TIMD4",   chr=5,  pheno="LIP", maf=0.35, orr=1.11, anc="EUR"),
    dict(rsid="rs6065906",  gene="PLTP",    chr=20, pheno="LIP", maf=0.18, orr=1.12, anc="EUR"),
    dict(rsid="rs2075650",  gene="TOMM40",  chr=19, pheno="LIP", maf=0.14, orr=1.13, anc="EUR"),
    dict(rsid="rs7395662",  gene="MADD",    chr=11, pheno="LIP", maf=0.25, orr=1.11, anc="EUR"),
]


def conf_to_or(conf, or_high, or_med, or_low):
    c = (conf or "").lower()
    if c.startswith("high"):
        return or_high
    if c.startswith("medium"):
        return or_med
    return or_low


# ----------------------------------------------------------- 인자
def parse_args():
    p = argparse.ArgumentParser(description="염색체 분할 합성 SNP 생성기 (v3)")
    p.add_argument("--cohort", default="BASE_Cohort_base.txt")
    p.add_argument("--catalog", default="kchip_final_data.xlsx")
    p.add_argument("--n-snps", type=int, default=1000000, help="총 SNP 수")
    p.add_argument("--outdir", default="kchip_out", help="염색체별 파일 출력 폴더")
    p.add_argument("--prefix", default="synthetic_kchip", help="파일 prefix")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--or-high", type=float, default=1.5, help="high 신뢰도 OR")
    p.add_argument("--or-medium", type=float, default=1.35, help="medium 신뢰도 OR")
    p.add_argument("--or-low", type=float, default=1.0)
    p.add_argument("--bg-maf-min", type=float, default=0.01)
    p.add_argument("--bg-maf-max", type=float, default=0.5)
    p.add_argument("--cat-maf-min", type=float, default=0.10)
    p.add_argument("--cat-maf-max", type=float, default=0.45)
    p.add_argument("--missing-geno-rate", type=float, default=0.0)
    p.add_argument("--chunk-size", type=int, default=5000)
    p.add_argument("--no-selftest", action="store_true", help="유의성 자체검증 생략")
    # 저빈도 인과 SNP power 보정(모든 인과 SNP이 GWAS 유의하도록)
    p.add_argument("--no-maf-boost", action="store_true", help="저빈도 OR 보정 끄기")
    p.add_argument("--no-candidates", action="store_true", help="후보 유전자 세트 제외")
    # LD 블록: 인과/후보 유전자를 상관된 여러 SNP(블록)으로 구성
    p.add_argument("--no-ld", action="store_true", help="LD 블록 비활성(유전자당 SNP 1개)")
    p.add_argument("--ld-block-size", type=int, default=20,
                   help="인과 유전자당 LD 블록 SNP 수(lead 포함)")
    p.add_argument("--ld-span-kb", type=int, default=100,
                   help="LD 블록 물리적 범위(kb) — r² 감쇠 스케일")
    p.add_argument("--ld-r2-max", type=float, default=0.95,
                   help="lead 인접 SNP 최대 r²")
    p.add_argument("--boost-or-rare", type=float, default=2.2, help="MAF<0.10 OR 하한")
    p.add_argument("--boost-or-low", type=float, default=1.8, help="MAF<0.18 OR 하한")
    p.add_argument("--boost-or-common", type=float, default=1.5, help="흔한 변이 OR 하한")
    return p.parse_args()


# ----------------------------------------------------------- 입력
def load_cohort(path):
    import csv
    d = {k: [] for k in ("id", "sex", "age", "HTN", "DM", "LIP")}
    with open(path, newline="") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            d["id"].append(row["T_ID"]); d["sex"].append(int(row["T_SEX"]))
            d["age"].append(int(row["T_AGE"]))
            d["HTN"].append(int(row["T_HTN"])); d["DM"].append(int(row["T_DM"]))
            d["LIP"].append(int(row["T_LIP"]))
    return {"id": np.array(d["id"]), "sex": np.array(d["sex"], np.int16),
            "age": np.array(d["age"], np.int16),
            "HTN": np.array(d["HTN"]), "DM": np.array(d["DM"]),
            "LIP": np.array(d["LIP"])}


def pheno_status(raw):
    s = np.full(raw.shape, 2, np.int8)  # 0 ctrl,1 case,2 miss
    s[raw == 1] = 0; s[raw == 2] = 1
    return s


def load_catalog(path, rng, args):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["3. SNP 카탈로그"]
    out, seen = [], set()
    for rsid, npap, gene, trait, conf, *_ in list(ws.iter_rows(values_only=True))[1:]:
        if not rsid or rsid in seen:
            continue
        seen.add(rsid)
        matched = []
        if trait:
            t = trait.lower()
            for ph, kws in PHENO_KEYWORDS.items():
                if any(k in t for k in kws):
                    matched.append(ph)
        primary = next((ph for ph in PHENO_PRIORITY if ph in matched), None)
        maf = APPROX_EAS_MAF.get(rsid, float(rng.uniform(args.cat_maf_min, args.cat_maf_max)))
        orr = conf_to_or(conf, args.or_high, args.or_medium, args.or_low) if primary else 1.0
        out.append(dict(rsid=rsid, gene=gene, trait=trait, conf=conf,
                        phenos=matched, primary=primary, maf=maf, orr=orr,
                        chr=GENE_CHR.get(gene), source="catalog", tier="strong"))
    return out


def merge_curated(catalog, args):
    """GWAS Catalog 기반 다인종 큐레이션 변이 주입(중복 rsID는 정보 보강)."""
    idx = {s["rsid"]: s for s in catalog}
    for k in CURATED_GWAS:
        note = k.get("note", f"{k['gene']} {k['pheno']} ({k['anc']})")
        src = f"gwascat:{k['anc']}"
        if k["rsid"] in idx:  # 카탈로그에 이미 있으면 정보 보강
            s = idx[k["rsid"]]
            s.update(maf=k["maf"], orr=k["orr"], primary=k["pheno"],
                     chr=k["chr"], gene=k["gene"], source=src, tier="strong")
            if k["pheno"] not in s["phenos"]:
                s["phenos"].append(k["pheno"])
        else:
            catalog.append(dict(rsid=k["rsid"], gene=k["gene"], trait=note,
                                conf=f"curated/{k['anc']}", phenos=[k["pheno"]],
                                primary=k["pheno"], maf=k["maf"], orr=k["orr"],
                                chr=k["chr"], source=src, tier="strong"))
    return catalog


def merge_candidates(catalog, args):
    """후보 유전자(약한 효과) 주입. 이미 강한 신호로 있으면 건너뜀."""
    if args.no_candidates:
        return catalog
    have = {s["rsid"] for s in catalog}
    for k in CANDIDATE_GENES:
        if k["rsid"] in have:
            continue
        note = k.get("note", f"{k['gene']} {k['pheno']} 후보({k['anc']})")
        catalog.append(dict(rsid=k["rsid"], gene=k["gene"], trait=note,
                            conf=f"candidate/{k['anc']}", phenos=[k["pheno"]],
                            primary=k["pheno"], maf=k["maf"], orr=k["orr"],
                            chr=k["chr"], source=f"cand:{k['anc']}",
                            tier="candidate"))
    return catalog


def boost_low_maf(catalog, args):
    """저빈도 인과 SNP은 case 수가 적을 때 검정력이 떨어지므로 OR 하한을 상향.
    (모든 인과 SNP이 GWAS에서 유의하게 검출되도록 하는 보정; 인자로 조정 가능)"""
    if args.no_maf_boost:
        return catalog
    for s in catalog:
        if not s["primary"]:
            continue
        if s.get("tier") == "candidate":   # 후보 유전자는 약한 효과 유지(보정 제외)
            continue
        if s["maf"] < 0.10:
            s["orr"] = max(s["orr"], args.boost_or_rare)    # 매우 저빈도
        elif s["maf"] < 0.18:
            s["orr"] = max(s["orr"], args.boost_or_low)     # 저빈도
        else:
            s["orr"] = max(s["orr"], args.boost_or_common)  # 흔한 변이 하한
    return catalog


# ------------------------------------------------- 조건부 유전형 생성
def _expit(x):
    return 1.0 / (1.0 + np.exp(-x))


def _solve_alpha(beta, Pg, K):
    g = np.array([0, 1, 2]); lo, hi = -25.0, 25.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if np.sum(_expit(mid + beta * g) * Pg) < K:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def gen_conditional(snp, status_map, Kmap, N, rng):
    """단일 위험 SNP을 표현형 조건부로 생성 -> (N,) dosage int8."""
    f = snp["maf"]
    Pg = np.array([(1 - f) ** 2, 2 * f * (1 - f), f ** 2])
    ph = snp["primary"]
    if ph is None or snp["orr"] == 1.0:
        return rng.binomial(2, f, size=N).astype(np.int8)
    g = np.array([0, 1, 2]); beta = math.log(snp["orr"])
    alpha = _solve_alpha(beta, Pg, Kmap[ph])
    pen = _expit(alpha + beta * g)
    case_d = pen * Pg; case_d /= case_d.sum()
    ctrl_d = (1 - pen) * Pg; ctrl_d /= ctrl_d.sum()
    s = status_map[ph]
    P = np.empty((N, 3))
    P[s == 0] = ctrl_d; P[s == 1] = case_d; P[s == 2] = Pg
    cdf = np.cumsum(P, axis=1); cdf[:, -1] = 1.0
    return (rng.random(N)[:, None] < cdf).argmax(axis=1).astype(np.int8)


# ------------------------------------------------- .bed 패킹
def pack_bed_chunk(codes, N):
    nb = (N + 3) // 4; pad = nb * 4 - N
    if pad:
        codes = np.vstack([codes, np.zeros((pad, codes.shape[1]), np.uint8)])
    codes = codes.reshape(nb, 4, codes.shape[1])
    w = np.array([1, 4, 16, 64], np.uint16)
    packed = (codes.astype(np.uint16) * w[None, :, None]).sum(1).astype(np.uint8)
    return packed.T.tobytes()


def dosage_to_bed(G, N, rng, miss):
    g = G.copy()
    if miss > 0:
        g[rng.random(g.shape) < miss] = 3
    return pack_bed_chunk(GENO_TO_CODE[g], N)


# ------------------------------------------------- Cochran-Armitage 추세검정
def ca_trend_p(g, status):
    """g:dosage(-1 결측), status:0ctrl/1case/2miss -> p-value(1df)."""
    m = (g >= 0) & (status < 2)
    gg = g[m]; y = (status[m] == 1)
    N = gg.size; R = int(y.sum())
    if R == 0 or R == N or N < 10:
        return 1.0
    n = np.array([(gg == i).sum() for i in (0, 1, 2)], float)
    r = np.array([y[gg == i].sum() for i in (0, 1, 2)], float)
    x = np.array([0., 1., 2.])
    S = float((x * r).sum())
    E = R / N * float((x * n).sum())
    var = (R * (N - R) / N**2) * (N * float((x**2 * n).sum())
                                  - float((x * n).sum())**2) / (N - 1)
    if var <= 0:
        return 1.0
    chi2 = (S - E) ** 2 / var
    return math.erfc(math.sqrt(chi2 / 2.0))  # P(chi2_1 > chi2)


# ------------------------------------------------- 염색체 배치
def assign_chromosomes(catalog, n_bg, rng):
    """각 SNP에 (chr, rank) 부여. 반환: chr->list of snp-dict(배경 포함)."""
    per_chr = {c: [] for c in CHR_LEN}
    # 인과 SNP: 알려진 chr, 없으면 길이가중 랜덤
    lens = np.array([CHR_LEN[c] for c in CHR_LEN], float)
    probs = lens / lens.sum()
    chrom_list = list(CHR_LEN)
    for s in catalog:
        c = s["chr"] if s["chr"] in CHR_LEN else int(rng.choice(chrom_list, p=probs))
        s["chr"] = c
        per_chr[c].append(s)
    # 배경 SNP: 길이가중 다항분포로 분배
    counts = rng.multinomial(n_bg, probs)
    for c, k in zip(chrom_list, counts):
        for _ in range(int(k)):
            per_chr[c].append(dict(rsid=None, primary=None, orr=1.0,
                                   source="bg", chr=c))
    return per_chr


# ------------------------------------------------- 부가 파일
def fam_text(coh):
    return "".join(f"{i} {i} 0 0 {s} -9\n"
                   for i, s in zip(coh["id"], coh["sex"]))


def write_shared(outdir, prefix, coh, catalog, famtxt):
    def code(v):
        return v if v in (1, 2) else -9
    with open(f"{outdir}/{prefix}.pheno", "w") as f:
        f.write("FID IID HTN DM LIP\n")
        for i in range(coh["id"].size):
            fid = coh["id"][i]
            f.write(f"{fid} {fid} {code(int(coh['HTN'][i]))} "
                    f"{code(int(coh['DM'][i]))} {code(int(coh['LIP'][i]))}\n")
    with open(f"{outdir}/{prefix}.covar", "w") as f:
        f.write("FID IID SEX AGE\n")
        for i in range(coh["id"].size):
            fid = coh["id"][i]
            f.write(f"{fid} {fid} {coh['sex'][i]} {coh['age'][i]}\n")
    with open(f"{outdir}/{prefix}.causal.tsv", "w") as f:
        f.write("rsID\tgene\tchr\tprimary_pheno\ttier\tall_phenos\tbaseline_MAF\t"
                "per_allele_OR\tsource\ttrait\n")
        for s in catalog:
            if not s["primary"]:
                continue
            f.write(f"{s['rsid']}\t{s.get('gene')}\t{s['chr']}\t{s['primary']}\t"
                    f"{s.get('tier','strong')}\t{','.join(s['phenos'])}\t"
                    f"{s['maf']:.4f}\t{s['orr']:.3f}\t"
                    f"{s['source']}\t{s.get('trait')}\n")
    with open(f"{outdir}/{prefix}.fam", "w") as f:
        f.write(famtxt)


# ------------------------------------------------- main
def main():
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    t0 = time.time()
    os.makedirs(args.outdir, exist_ok=True)

    coh = load_cohort(args.cohort)
    N = coh["id"].size
    catalog = load_catalog(args.catalog, rng, args)
    catalog = merge_curated(catalog, args)
    catalog = merge_candidates(catalog, args)
    catalog = boost_low_maf(catalog, args)
    causal = [s for s in catalog if s["primary"]]
    strong = [s for s in causal if s.get("tier") != "candidate"]
    cand = [s for s in causal if s.get("tier") == "candidate"]
    n_cat = len(catalog)
    K = 1 if args.no_ld else max(1, args.ld_block_size)
    n_lead = len(causal)               # LD 블록 lead 좌위 수
    n_single = n_cat - n_lead          # 비인과 카탈로그 단일 SNP
    fixed = n_lead * K + n_single      # 인과 블록 + 단일 SNP 총합
    M = max(args.n_snps, fixed)
    n_bg = M - fixed

    status_map = {ph: pheno_status(coh[ph]) for ph in ("HTN", "DM", "LIP")}
    Kmap = {}
    for ph, s in status_map.items():
        nm = s != 2
        Kmap[ph] = float((s[nm] == 1).mean()) if nm.any() else 0.0

    print(f"[info] 개체 {N:,} | 총 SNP {M:,} (인과 lead {n_lead}×블록{K} + 단일 {n_single} "
          f"+ 배경 {n_bg:,})")
    print(f"[info] 인과 SNP {len(causal)}개 = 강한신호 {len(strong)} + 후보 {len(cand)} "
          f"| 고유유전자 {len({s.get('gene') for s in causal})}개 "
          f"| LD 블록 {'OFF' if args.no_ld else f'ON(size={K}, span={args.ld_span_kb}kb, r2max={args.ld_r2_max})'}")
    print(f"[info] OR high={args.or_high} med={args.or_medium} | 유병률 "
          f"HTN={Kmap['HTN']:.3f} DM={Kmap['DM']:.3f} LIP={Kmap['LIP']:.3f}")

    per_chr = assign_chromosomes(catalog, n_bg, rng)
    famtxt = fam_text(coh)
    write_shared(args.outdir, args.prefix, coh, catalog, famtxt)

    causal_geno = {}   # 유의성 검증용 (rsID -> dosage)
    chrom_summary = []

    for c in sorted(CHR_LEN):
        snps = per_chr[c]
        if not snps:
            continue
        L = CHR_LEN[c]
        lead_snps = [s for s in snps if s.get("rsid") and s["primary"]]   # LD 블록
        single_snps = [s for s in snps if s.get("rsid") and not s["primary"]]
        n_bg_c = sum(1 for s in snps if not s.get("rsid"))

        base = f"{args.outdir}/{args.prefix}_chr{c}"
        fb = open(base + ".bim", "w")
        bed = open(base + ".bed", "wb"); bed.write(BED_MAGIC)
        shutil.copyfile(f"{args.outdir}/{args.prefix}.fam", base + ".fam")

        cursor = [0]                       # 염색체 내 bp 커서(오름차순 유지)
        counters = {"bg": 0, "written": 0, "leads": 0}

        def bp_next(lo, hi):
            cursor[0] = min(cursor[0] + int(rng.integers(lo, hi)), L)
            return cursor[0]

        def rand_alleles(k):
            a1 = rng.integers(0, 4, size=k); a2 = (a1 + rng.integers(1, 4, size=k)) % 4
            return NUCLEOTIDES[a1], NUCLEOTIDES[a2]

        def emit(G, rsids, bps):
            k = G.shape[1]
            bed.write(dosage_to_bed(G, N, rng, args.missing_geno_rate))
            A1, A2 = rand_alleles(k)
            fb.write("\n".join(
                f"{c}\t{rsids[i]}\t0\t{bps[i]}\t{A1[i]}\t{A2[i]}" for i in range(k)) + "\n")
            counters["written"] += k

        def emit_background(n):
            done = 0
            while done < n:
                kk = min(args.chunk_size, n - done)
                p = rng.uniform(args.bg_maf_min, args.bg_maf_max, size=kk)
                G = ((rng.random((N, kk)) < p).astype(np.int8)
                     + (rng.random((N, kk)) < p).astype(np.int8))
                bps = [bp_next(500, 5000) for _ in range(kk)]
                rsids = [f"bg_chr{c}_{counters['bg']+i+1}" for i in range(kk)]
                counters["bg"] += kk
                emit(G, rsids, bps)
                done += kk

        def emit_single(s):
            g = gen_conditional(s, status_map, Kmap, N, rng)
            emit(g.reshape(N, 1), [s["rsid"]], [bp_next(500, 5000)])

        def emit_block(lead):
            """lead 좌위를 상관된 K개 SNP(LD 블록)으로 생성."""
            maf = lead["maf"]
            lead_g = gen_conditional(lead, status_map, Kmap, N, rng)
            causal_geno[lead["rsid"]] = (lead_g.copy(), lead["primary"])
            counters["leads"] += 1
            if args.no_ld:
                emit(lead_g.reshape(N, 1), [lead["rsid"]], [bp_next(500, 5000)])
                return
            # 블록 내 bp(작은 간격, 오름차순), lead는 중앙
            bps = [bp_next(300, 2000) for _ in range(K)]
            lead_idx = K // 2
            lead_bp = bps[lead_idx]
            span = max(args.ld_span_kb * 1000, 1)
            kdecay = math.log(max(args.ld_r2_max, 0.2) / 0.05)
            # lead 대립유전자 분해
            a1 = np.where(lead_g == 2, 1,
                          np.where(lead_g == 0, 0, rng.integers(0, 2, N))).astype(np.int8)
            a2 = (lead_g - a1).astype(np.int8)
            G = np.empty((N, K), np.int8)
            rsids = [None] * K
            nb = 0
            for i in range(K):
                if i == lead_idx:
                    G[:, i] = lead_g; rsids[i] = lead["rsid"]
                    continue
                d = abs(bps[i] - lead_bp)
                r2 = args.ld_r2_max * math.exp(-kdecay * d / span)
                r2 = min(max(r2, 0.02), 0.99)
                cprob = math.sqrt(r2)            # 대립유전자 복사확률 = r = sqrt(r2)
                b1 = np.where(rng.random(N) < cprob, a1,
                              (rng.random(N) < maf).astype(np.int8))
                b2 = np.where(rng.random(N) < cprob, a2,
                              (rng.random(N) < maf).astype(np.int8))
                G[:, i] = (b1 + b2).astype(np.int8)
                nb += 1; rsids[i] = f"{lead['rsid']}_ld{nb}"
            emit(G, rsids, bps)

        # 인과 블록·단일 SNP을 배경 사이에 흩뿌려 배치(현실적 Manhattan)
        units = ([("block", s) for s in lead_snps]
                 + [("single", s) for s in single_snps])
        rng.shuffle(units)
        n_units = len(units)
        gaps = n_units + 1
        bg_per_gap = n_bg_c // gaps
        bg_extra = n_bg_c - bg_per_gap * gaps
        for ui in range(gaps):
            emit_background(bg_per_gap + (bg_extra if ui == gaps - 1 else 0))
            if ui < n_units:
                typ, s = units[ui]
                emit_block(s) if typ == "block" else emit_single(s)

        fb.close(); bed.close()
        sz = os.path.getsize(base + ".bed") / 1e6
        chrom_summary.append((c, counters["written"], counters["leads"], sz))
        print(f"\r[chr{c:>2}] SNP {counters['written']:>7,} "
              f"(인과블록 {counters['leads']:>2}) .bed {sz:7.1f} MB "
              f"| {time.time()-t0:6.1f}s", end="\n")

    # 염색체 요약 저장
    with open(f"{args.outdir}/{args.prefix}.chrom_summary.tsv", "w") as f:
        f.write("chr\tn_snp\tn_causal\tbed_MB\n")
        for c, n_c, nca, sz in chrom_summary:
            f.write(f"{c}\t{n_c}\t{nca}\t{sz:.1f}\n")

    # ---- (2) 유의성 자체검증: 인과 SNP CA 추세검정 ----
    if not args.no_selftest and causal_geno:
        tier_of = {s["rsid"]: s.get("tier", "strong") for s in causal}
        gene_of = {s["rsid"]: s.get("gene") for s in causal}
        rows = []
        for s in causal:
            gg, ph = causal_geno.get(s["rsid"], (None, None))
            if gg is None:
                continue
            p = ca_trend_p(gg, status_map[ph])
            rows.append((s["rsid"], ph, s["orr"], s["maf"], p, tier_of[s["rsid"]]))

        # (a) 강한 신호 — 목표: genome-wide 유의
        print("\n[selftest] 강한 인과 SNP (목표 p<5e-8):")
        print(f"{'rsID':<12}{'pheno':<5}{'OR':>5}{'MAF':>6}{'p-value':>12}  sig")
        n_sig = {"HTN": 0, "DM": 0, "LIP": 0}; n_tot = {"HTN": 0, "DM": 0, "LIP": 0}
        for rsid, ph, orr, maf, p, t in sorted(
                [r for r in rows if r[5] != "candidate"], key=lambda r: r[4]):
            n_tot[ph] += 1; n_sig[ph] += int(p < GW_SIG)
            flag = "***" if p < GW_SIG else ("*" if p < 1e-5 else "")
            print(f"{rsid:<12}{ph:<5}{orr:>5.2f}{maf:>6.2f}{p:>12.2e}  {flag}")
        print("  -> genome-wide 유의: " + " | ".join(
            f"{ph} {n_sig[ph]}/{n_tot[ph]}" for ph in ("HTN", "DM", "LIP")))

        # (b) 후보 유전자 — 목표: p>1e-5 (약한 신호)
        cand_rows = [r for r in rows if r[5] == "candidate"]
        if cand_rows:
            print("\n[selftest] 후보 유전자 SNP (목표 p>1e-5):")
            print(f"{'rsID':<12}{'gene':<9}{'pheno':<5}{'OR':>5}{'MAF':>6}{'p-value':>12}")
            n_ok = 0
            for rsid, ph, orr, maf, p, t in sorted(cand_rows, key=lambda r: r[4]):
                n_ok += int(p > 1e-5)
                print(f"{rsid:<12}{str(gene_of.get(rsid)):<9}{ph:<5}"
                      f"{orr:>5.2f}{maf:>6.2f}{p:>12.2e}")
            print(f"  -> p>1e-5(후보권) 비율: {n_ok}/{len(cand_rows)}")

    print(f"\n[done] 출력 폴더: {args.outdir}/  (염색체별 {args.prefix}_chr*.bed/.bim/.fam)")
    print(f"[done] 공유: {args.prefix}.fam/.pheno/.covar/.causal.tsv/.chrom_summary.tsv")
    print(f"[time] 총 {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
