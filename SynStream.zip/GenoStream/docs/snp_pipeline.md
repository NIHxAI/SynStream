# Synthetic SNP-array construction

`src/make_synthetic_snp.py`

## Overview

Generates ~1,000,000 autosomal SNPs for the cohort subjects and writes them as chromosome-split
PLINK binary files, together with phenotype, covariate, and ground-truth annotation files.

## Three-tier signal design

| Tier | Target *p* | OR | Role |
|---|---|---|---|
| strong | < 5e-8 | high (power-boosted) | established causal loci, genome-wide significant |
| candidate | > 1e-5 | weak (1.06–1.14) | real but sub-threshold loci |
| background | uniform | 1 (none) | phenotype-independent null |

## How genotypes are generated

**Background (null) SNP** — minor-allele frequency `f` is drawn, then each allele ~ Bernoulli(`f`);
the two alleles are summed to a dosage (0/1/2). This is Hardy-Weinberg equilibrium:

```
P(g=0) = (1-f)^2   P(g=1) = 2f(1-f)   P(g=2) = f^2
```

**Causal SNP (phenotype-conditional)** — a per-allele logistic model is assumed:

```
logit( P(disease | g) ) = alpha + beta * g,     beta = ln(OR)
```

`alpha` is solved so the population prevalence matches the cohort. Genotypes are then sampled from the
distribution conditional on the observed case/control status, so risk-allele frequency is higher in
cases. Missing phenotype → HWE baseline.

## Curated GWAS-Catalog loci

Disease-associated variants are curated across ancestries (EAS / EUR / multi-ancestry) for
hypertension, type 2 diabetes, and dyslipidemia (e.g., TCF7L2, KCNQ1, CDKAL1, SLC30A8, PAX4, FGF5,
ATP2B1, SH2B3, APOA5, CETP, LDLR, PCSK9, APOE). Variants present in the input catalog are enriched
with these values. A candidate-gene set (weak effects) is added separately.

> Effect sizes and MAFs are **illustrative** values based on catalog loci. Replace `CURATED_GWAS` /
> `CANDIDATE_GENES` in the script with empirical estimates (e.g., gnomAD EAS) for specific realism.

## LD blocks

Each causal/candidate lead locus is expanded into a block of correlated SNPs. A neighbor allele copies
the lead allele with probability `sqrt(r2)`, otherwise it is drawn independently at the lead MAF, so
the allele correlation is `sqrt(r2)` (genotype r² ≈ target r²). r² decays exponentially with physical
distance from the lead, producing a realistic association peak.

```
neighbor_allele = lead_allele          with prob sqrt(r2)
                = Bernoulli(MAF)        otherwise
r2(d) = r2_max * exp(-k * d / span)
```

## Power boost (strong tier only)

Because power depends on case count, MAF, and OR, low-MAF strong loci receive an OR floor so that all
strong loci reach genome-wide significance in the full cohort. Candidates are excluded from the boost.

## Key parameters

| Flag | Default | Meaning |
|---|---|---|
| `--n-snps` | 1000000 | total SNPs |
| `--ld-block-size` | 20 | SNPs per causal locus (incl. lead) |
| `--ld-span-kb` | 100 | block span (r² decay scale) |
| `--ld-r2-max` | 0.95 | max r² near the lead |
| `--no-ld` | off | one SNP per locus |
| `--no-candidates` | off | drop the candidate tier |
| `--or-high / --or-medium` | 1.5 / 1.35 | catalog-confidence ORs |
| `--boost-or-rare/low/common` | 2.2 / 1.8 / 1.5 | strong-tier OR floors by MAF |
| `--seed` | 42 | reproducibility |

## Self-test

After generation the script runs a Cochran-Armitage trend test on the planted loci and prints, per
phenotype, how many strong loci reach *p* < 5e-8 and how many candidates stay *p* > 1e-5.
