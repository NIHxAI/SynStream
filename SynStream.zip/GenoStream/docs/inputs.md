# Input file formats

## 1. Cohort (tab-separated .txt)

Header + one row per subject.

| Column | Meaning | Coding |
|---|---|---|
| `T_ID` | subject ID | string (links SNP + brain data) |
| `T_SEX` | sex | 1 = male, 2 = female |
| `T_AGE` | age (years) | integer |
| `T_HTN` | hypertension | 1 = normal, 2 = disease, 99999 = missing |
| `T_DM` | type 2 diabetes | 1 = normal, 2 = disease, 99999 = missing |
| `T_LIP` | dyslipidemia | 1 = normal, 2 = disease, 99999 = missing |

A 200-subject synthetic demo is in `examples/example_cohort.txt`.

## 2. SNP catalog (.xlsx)

Worksheet **`3. SNP 카탈로그`** with (at least) these columns:

| Column | Meaning |
|---|---|
| `rsID` | variant ID |
| `Paper 수` | number of supporting papers |
| `유전자` | gene symbol |
| `연관 형질·질환` | associated trait/disease text (keyword-classified into HTN/DM/LIP) |
| `신뢰도/출처` | confidence/source (high/medium/low) |
| `Paper IDs` | references (optional) |

A minimal demo is in `examples/example_catalog.xlsx`. Curated multi-ancestry loci and a candidate-gene
set are **built into the script**, so even a small catalog yields most causal signals.

## 3. NeuroStream assets (brain pipeline only)

`cohort*_sample_updated.csv` from https://github.com/NIHxAI/NeuroStream — used to anchor ROI
means/SDs. Not redistributed here; clone the upstream repository.
