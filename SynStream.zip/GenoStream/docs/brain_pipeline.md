# Synthetic brain-imaging volumetric construction

`src/make_brain_volume.py`

## Overview

Generates matched brain volumes for **66 regions of interest (ROIs)** in the **NeuroStream** (Cho et al., Bioinform Adv 2026; PMID 42109578) CSV
format (73 columns), for the same subjects as the SNP data (linked by `T_ID`).

## Inputs

- Cohort txt (same as the SNP pipeline).
- NeuroStream sample CSVs (`cohort*_sample_updated.csv`) — used only to anchor per-ROI means/SDs.
  Clone: `git clone https://github.com/NIHxAI/NeuroStream`.

## Coding note (important)

NeuroStream codes disease as **1 = disease, 2 = non-disease**, which is the **opposite** of the
cohort (`1 = normal, 2 = disease`). The pipeline flips `cov_htn` / `cov_dm` accordingly. Sex coding
(1 = male, 2 = female) is identical. `age_group = clip(age//10 - 4, 0, 4)` (0=40s … 4=80s).

## Generative model

Each ROI volume = anchor mean x factor x size-scaling + noise.

- **ICV (head size):** sex-dependent mean, plus HMGA2 (rs10784502) +1.5%/allele. Regions scale
  partially with ICV.
- **Age:** tissue atrophy (strongest in medial temporal lobe: hippocampus, entorhinal, amygdala),
  ventricular enlargement.
- **Disease:** tissue atrophy and ventricular enlargement (T2D > HTN > dyslipidemia).
- **Imaging genetics:** APOE e4 dosage (hippocampus/entorhinal/amygdala down, ventricle up);
  ENIGMA loci TESC & MSRB3 (hippocampus), KTN1 (putamen).
- **Noise:** ~0.62 x anchor SD (Gaussian).

## Anatomical consistency (enforced)

- whole_brain = cerebral grey + cerebral white + cerebellum
- lateral_ventricle_w_inf = lateral_ventricle + inferior horn
- left + right = total (for the 10 L/R-paired structures)
- ICV > whole_brain for every subject

## Outputs

| File | Content |
|---|---|
| `brain_volume_synthetic_neurostream.csv` | 73-col NeuroStream format (loads directly in the app) |
| `brain_volume_synthetic_extended.csv` | + `IID`, `cov_lip`, `cov_apoe_e4`, and 4 brain SNP genotypes (imaging-genetics) |
| `brain_effects_truth.tsv` | ground-truth of planted effects |

## Validation

Console prints group means: hippocampus is smaller in HTN / T2D cases and APOE e4 carriers; lateral
ventricle is larger in HTN. See `figures/brain_validation.png`.
