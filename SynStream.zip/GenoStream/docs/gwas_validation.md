# GWAS validation

## 1. Merge chromosomes (optional) and run PLINK2 --glm

See `examples/run_gwas.sh`. Per phenotype (DM/HTN/LIP), logistic regression with sex + age covariates:

```bash
plink2 --bfile out_snp/synthetic_kchip_all \
  --pheno out_snp/synthetic_kchip.pheno --pheno-name DM \
  --covar out_snp/synthetic_kchip.covar --covar-name SEX,AGE \
  --glm hide-covar --out out_gwas/dm_all
```

## 2. Plots (R qqman)

`examples/plot_gwas.R` renders Manhattan and QQ plots. Expected pattern:

- **Manhattan:** multiple genome-wide significant peaks (red line = 5e-8), each a vertical cluster of
  correlated SNPs = a planted LD block. Background stays below the suggestive line (blue = 1e-5).
- **QQ:** lower quantiles on the diagonal (well-calibrated null, no genomic inflation), sharp
  upper-tail departure = true planted signal.

## 3. Recover ground truth

Compare top loci against `out_snp/synthetic_kchip.causal.tsv` (`tier = strong` should be
genome-wide significant; `tier = candidate` should be p > 1e-5). Export a formatted table:

```bash
python src/glm_to_xlsx.py out_gwas/dm_all.DM.glm.logistic.hybrid \
  --causal out_snp/synthetic_kchip.causal.tsv --out dm_results.xlsx
```

## 4. LD / clumping check

```bash
plink --bfile out_snp/synthetic_kchip_chr10 --r2 --ld-window-kb 200 --ld-window-r2 0.2 --out ld_chr10
```
