# data/

Place your **own** cohort and SNP catalog here (git-ignored by default):

- `BASE_Cohort_base.txt` — cohort (see `docs/inputs.md`)
- `kchip_final_data.xlsx` — SNP catalog with sheet `3. SNP 카탈로그`

Real individual-level data must **not** be committed to a public repository.
Use `examples/` for safe, synthetic demo inputs.
