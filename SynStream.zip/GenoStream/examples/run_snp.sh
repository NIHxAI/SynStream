#!/usr/bin/env bash
# End-to-end synthetic SNP-array demo (small, fast).
# For realistic GWAS peaks, use your full cohort and --n-snps 1000000.
set -euo pipefail
python src/make_synthetic_snp.py \
  --cohort examples/example_cohort.txt \
  --catalog examples/example_catalog.xlsx \
  --n-snps 20000 --ld-block-size 10 \
  --outdir out_snp
echo "Done -> out_snp/  (see synthetic_kchip.causal.tsv for ground truth)"
