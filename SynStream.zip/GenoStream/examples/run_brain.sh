#!/usr/bin/env bash
# Matched brain-volume demo. Requires NeuroStream assets for ROI anchors.
set -euo pipefail
[ -d NeuroStream ] || git clone https://github.com/NIHxAI/NeuroStream
python src/make_brain_volume.py \
  --cohort examples/example_cohort.txt \
  --sample-dir NeuroStream/assets \
  --outdir out_brain
echo "Done -> out_brain/  (neurostream + extended CSV + effects truth)"
