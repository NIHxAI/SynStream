#!/usr/bin/env Rscript
# Manhattan + QQ from PLINK2 --glm output. Usage: Rscript plot_gwas.R <gwas_outdir>
suppressMessages(library(qqman))
args <- commandArgs(trailingOnly = TRUE)
dir  <- ifelse(length(args) >= 1, args[1], "out_gwas")
for (ph in c("htn", "dm", "lip")) {
  f <- list.files(dir, pattern = paste0("^", ph, "_all\\..*glm.*"), full.names = TRUE)
  if (length(f) == 0) next
  d <- read.table(f[1], header = TRUE, comment.char = "", sep = "\t", check.names = FALSE)
  names(d)[names(d) == "#CHROM"] <- "CHR"
  d <- d[d$TEST == "ADD" & !is.na(d$P), c("CHR", "POS", "ID", "P")]
  colnames(d) <- c("CHR", "BP", "SNP", "P")
  png(file.path(dir, paste0(ph, "_manhattan.png")), 2400, 1200, res = 150)
  manhattan(d, main = paste(toupper(ph), "GWAS")); dev.off()
  png(file.path(dir, paste0(ph, "_qq.png")), 1400, 1400, res = 150)
  qq(d$P, main = paste(toupper(ph), "GWAS QQ Plot")); dev.off()
}
cat("Plots written to", dir, "\n")
