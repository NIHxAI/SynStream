#!/usr/bin/env bash
# PLINK2 GWAS for each phenotype. Usage: bash examples/run_gwas.sh <snp_outdir> <gwas_outdir>
set -euo pipefail
SNP="${1:-out_snp}"; OUT="${2:-out_gwas}"; PREFIX="synthetic_kchip"
mkdir -p "$OUT"

# 1) merge chromosomes -> one fileset
: > "$OUT/merge_list.txt"
for c in $(seq 2 22); do
  [ -f "$SNP/${PREFIX}_chr${c}.bed" ] && echo "$SNP/${PREFIX}_chr${c}" >> "$OUT/merge_list.txt"
done
plink2 --bfile "$SNP/${PREFIX}_chr1" \
  --pmerge-list "$OUT/merge_list.txt" \
  --make-bed --out "$OUT/${PREFIX}_all"

# 2) logistic GWAS per phenotype
for PH in HTN DM LIP; do
  plink2 --bfile "$OUT/${PREFIX}_all" \
    --pheno "$SNP/${PREFIX}.pheno" --pheno-name "$PH" \
    --covar "$SNP/${PREFIX}.covar" --covar-name SEX,AGE \
    --glm hide-covar --out "$OUT/${PH,,}_all"
done
echo "Done -> $OUT/"
